const mongoose = require('mongoose');
const Product = require('./product.model');
const Variant = require('./variant.model');
const VariantUnit = require('./variant_unit.model');
const ProductMapper = require('./product.mapper');
const AppError = require('../../utils/appError.util');
const ProductAuditLogService = require('../audit_logs/product_audit_log/product_log.service');
const { AUDIT_ACTIONS } = require('../../constants/audit');

class ProductService {
    static async createProduct(data, actorId = null, metadata = {}) {
        const { name, category_id, ...rest } = data;

        if (category_id) {
            const Category = require('../categories/category.model');
            const category = await Category.findById(category_id);
            if (!category) {
                throw new AppError(
                    'Category not found',
                    404,
                    'CATEGORY_NOT_FOUND'
                );
            }
        }

        try {
            const product = new Product({
                name,
                category_id,
                ...rest,
            });

            await product.save();

            await this._createProductAuditLog({
                action: AUDIT_ACTIONS.CREATE_PRODUCT,
                targetType: 'PRODUCT',
                product,
                actorId,
                metadata,
                changes: {
                    name: {
                        from: null,
                        to: product.name,
                    },
                    category_id: {
                        from: null,
                        to: product.category_id,
                    },
                    status: {
                        from: null,
                        to: product.status,
                    },
                    slug: {
                        from: null,
                        to: product.slug,
                    },
                },
            });

            return ProductMapper.toResponseDTO(product);

        } catch (error) {
            if (error.code === 11000) {
                throw new AppError(
                    'Slug already exists',
                    409,
                    'SLUG_CONFLICT'
                );
            }

            throw error;
        }
    }

    static async getProductById(productId, options = {}) {
        const { includeUnits = true } = options;

        const product = await Product.findOne({
            _id: productId,
            is_deleted: false
        }).lean();

        if (!product) {
            throw new AppError('Product not found', 404, 'PRODUCT_NOT_FOUND');
        }

        return this._buildProductDetail(product, includeUnits);
    }

    static async getProductBySlug(slug, options = {}) {
        const { includeUnits = true } = options;

        const product = await Product.findOne({
            slug,
            is_deleted: false
        }).lean();

        if (!product) {
            throw new AppError('Product not found', 404, 'PRODUCT_NOT_FOUND');
        }

        return this._buildProductDetail(product, includeUnits);
    }

    static async getAllProducts(
        page = 1,
        limit = 20,
        filters = {}
    ) {
        const skip = (page - 1) * limit;
        const query = {};


        if (filters.category_id) {
            query.category_id = filters.category_id;
        }


        if (filters.status) {
            query.status = filters.status;
        }


        if (filters.min_price || filters.max_price) {
            const priceConditions = [];

            if (filters.min_price !== undefined) {
                priceConditions.push({
                    max_price: { $gte: filters.min_price }
                });
            }

            if (filters.max_price !== undefined) {
                priceConditions.push({
                    min_price: { $lte: filters.max_price }
                });
            }

            if (priceConditions.length > 0) {
                query.$and = priceConditions;
            }
        }

        const search = filters.search?.trim();
        let sortBy = { created_at: -1 };
        if (search) {
            if (!query.status) {
                query.status = 'ACTIVE';
            }

            if (query.status === 'ACTIVE') {
                query.$text = { $search: search };
                sortBy = { score: { $meta: 'textScore' }, ...sortBy };
            } else {
                query.$or = [
                    { name: { $regex: search, $options: 'i' } },
                    { short_description: { $regex: search, $options: 'i' } },
                    { search_keywords: { $regex: search, $options: 'i' } },
                ];
            }
        } else if (filters.sortBy === 'popular') {
            sortBy = { sold_count: -1, rating_avg: -1 };
        } else if (filters.sortBy === 'rating') {
            sortBy = { rating_avg: -1 };
        } else if (filters.sortBy === 'price_asc') {
            sortBy = { min_price: 1 };
        } else if (filters.sortBy === 'price_desc') {
            sortBy = { max_price: -1 };
        }


        const total = await Product.countDocuments(query);
        const products = await Product.find(query)
            .skip(skip)
            .limit(limit)
            .sort(sortBy)
            .lean();

        return {
            data: products.map((p) => ProductMapper.toListDTO(p)),
            pagination: {
                current_page: page,
                total_pages: Math.ceil(total / limit),
                total_items: total,
                per_page: limit,
            },
        };
    }

    static async updateProduct(productId, updateData, actorId = null, metadata = {}) {
        if (!updateData || Object.keys(updateData).length === 0) {
            throw new AppError(
                'No valid fields to update',
                400,
                'VALIDATION_ERROR'
            );
        }

        try {
            const currentProduct = await Product.findById(productId);

            if (!currentProduct) {
                throw new AppError(
                    'Product not found',
                    404,
                    'PRODUCT_NOT_FOUND'
                );
            }

            const product = await Product.findByIdAndUpdate(
                productId,
                { $set: updateData },
                { new: true, runValidators: true }
            );

            if (!product) {
                throw new AppError(
                    'Product not found',
                    404,
                    'PRODUCT_NOT_FOUND'
                );
            }

            await this._createProductAuditLog({
                action: AUDIT_ACTIONS.UPDATE_PRODUCT,
                targetType: 'PRODUCT',
                product,
                actorId,
                metadata,
                changes: this._buildFieldChanges(
                    currentProduct,
                    product,
                    Object.keys(updateData)
                ),
            });

            return ProductMapper.toResponseDTO(product);
        } catch (error) {
            if (error.code === 11000) {
                throw new AppError(
                    'Slug already exists',
                    409,
                    'SLUG_CONFLICT'
                );
            }
            throw error;
        }
    }

    static async deleteProduct(productId, actorId = null, metadata = {}) {
        const session = await mongoose.startSession();
        session.startTransaction();

        let product = null;
        let variantCount = 0;

        try {
            product = await Product.findById(productId).session(
                session
            );
            if (!product) {
                throw new AppError(
                    'Product not found',
                    404,
                    'PRODUCT_NOT_FOUND'
                );
            }


            variantCount = await Variant.countDocuments({
                product_id: productId,
            }).session(session);

            await Product.softDelete(productId, session);

            await session.commitTransaction();

            await this._createProductAuditLog({
                action: AUDIT_ACTIONS.DELETE_PRODUCT_SOFT,
                targetType: 'PRODUCT',
                product,
                actorId,
                metadata,
                changes: {
                    is_deleted: {
                        from: false,
                        to: true,
                    },
                    cascade_variants: {
                        from: 0,
                        to: variantCount,
                    },
                },
            });

            return {
                message: 'Product deleted successfully (soft delete)',
                productId,
            };
        } catch (error) {
            await session.abortTransaction();
            throw error;
        } finally {
            session.endSession();
        }
    }

    static async recalcuatePriceCache(productId) {
        try {
            await Product.updatePriceCache(productId);
        } catch (error) {
            console.error(`Failed to update price cache for product ${productId}:`, error);

        }
    }

    static async updateProductStats(productId, stats) {
        await Product.findByIdAndUpdate(productId, { $set: stats });
    }

    static async getProductsByCategory(categoryId, limit = 50) {
        const products = await Product.find({
            category_id: categoryId,
            status: 'ACTIVE',
        })
            .limit(limit)
            .sort({ sold_count: -1 })
            .lean();

        return products.map((p) => ProductMapper.toListDTO(p));
    }

    static async searchProducts(query, limit = 20) {
        const products = await Product.find(
            { status: 'ACTIVE', $text: { $search: query } },
            { score: { $meta: 'textScore' } }
        )
            .sort({ score: { $meta: 'textScore' } })
            .limit(limit)
            .lean();

        return products.map((p) => ProductMapper.toListDTO(p));
    }

    static async _buildProductDetail(product, includeUnits = true) {
        const variants = await Variant.find(
            { product_id: product._id },
            null,
            { includeDeleted: false }
        ).lean();

        let unitsMap = {};

        if (includeUnits && variants.length > 0) {
            const variantIds = variants.map(v => v._id);

            const allUnits = await VariantUnit.find({
                variant_id: { $in: variantIds }
            }).lean();

            for (const unit of allUnits) {
                const key = unit.variant_id.toString();
                if (!unitsMap[key]) {
                    unitsMap[key] = [];
                }
                unitsMap[key].push(unit);
            }
        }

        const variantsWithUnits = variants.map((variant) => ({
            ...variant,
            units: includeUnits
                ? (unitsMap[variant._id.toString()] || [])
                : [],
        }));

        return ProductMapper.toDetailDTO(product, variantsWithUnits);
    }

    static _buildFieldChanges(before, after, fields) {
        return fields.reduce((changes, field) => {
            const fromValue = this._toAuditValue(before?.[field]);
            const toValue = this._toAuditValue(after?.[field]);

            if (JSON.stringify(fromValue) !== JSON.stringify(toValue)) {
                changes[field] = {
                    from: fromValue,
                    to: toValue,
                };
            }

            return changes;
        }, {});
    }

    static _toAuditValue(value) {
        if (value === undefined || value === null) return null;
        if (value instanceof Date) return value;
        if (value?.toString && value.constructor?.name === 'ObjectId') {
            return value.toString();
        }
        if (Array.isArray(value)) {
            return value.map((item) => this._toAuditValue(item));
        }
        if (value?.toObject) {
            return this._toAuditValue(value.toObject());
        }
        if (typeof value === 'object') {
            return Object.fromEntries(
                Object.entries(value).map(([key, item]) => [
                    key,
                    this._toAuditValue(item),
                ])
            );
        }
        return value;
    }

    static async _createProductAuditLog({
        action,
        targetType,
        product,
        actorId = null,
        actorType = 'USER',
        metadata = {},
        changes = {},
    }) {
        await ProductAuditLogService.createLog({
            actor_id: actorId,
            actor_type: actorType,
            action,
            target_type: targetType,
            product_id: product?._id || null,
            variant_id: null,
            unit_id: null,
            sku: null,
            changes,
            ip_address: metadata.ip || null,
            user_agent: metadata.userAgent || null,
        });
    }
}

module.exports = ProductService;
