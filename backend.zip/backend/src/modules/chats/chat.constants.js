


const CHAT_INTENTS = {
    GREETING: 'GREETING',
    ASK_PRICE: 'ASK_PRICE',
    SEARCH_PRODUCT: 'SEARCH_PRODUCT',
    ORDER_STATUS: 'ORDER_STATUS',
    UNKNOWN: 'UNKNOWN'
};

const CHAT_CONFIG = {
    MIN_CONFIDENCE: 0.4,
    MAX_RETRY: 2,
    DEFAULT_MODEL: 'gemini-1.5-flash'
};

module.exports = { CHAT_INTENTS, CHAT_CONFIG };